# hugo-bigbig

一个简洁的 hugo 博客主题

Demo：[https://www.xizero.com](https://www.xizero.com)

![](./demo/hugo.png)

![](./demo/hugo_tags.png)

![](./demo/hugo_list.png)