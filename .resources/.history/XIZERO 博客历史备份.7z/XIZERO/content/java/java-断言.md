+++
title = "Java 断言"
date = "2017-03-19T20:19:36+08:00"
categories="java"
+++
```java
assert  boolean ;
assert  boolean : error info;
```

开启 
```
java -ea 字节码
```
