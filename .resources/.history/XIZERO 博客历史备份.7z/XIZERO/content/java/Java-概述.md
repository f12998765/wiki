+++
title = "Java 概述"
date = "2016-11-18T18:20:00+08:00"
categories="java"
+++

## Java的历史

1991 年Sun公司的James Gosling等人开始开发名称为 Oak 的语言

1994年将Oak语言更名为Java。

随着互联网的兴起，Java语言迅速崛起 。

2009年04月20日，美国甲骨文公司收购Sun，取得java的版权。

## **Java技术体系**

**JAVASE：**`Java Platform Standard Edition`，完成桌面应用程序的开发，是其它两者的基础;

**JAVAEE：**`Java Platform Enterprise Edition`，开发企业环境下的应用程序，主要针对web程序开发;

**JAVAME：**`Java Platform Micro Edition`，开发电子消费产品和嵌入式设备，如手机中的程序。

## Java的特性

Java 是一种面向对象的编程语言。

其他，请自行Google了解。
