+++
title = "java 泛型 TKVE 含义"
date = "2016-11-24T15:55:43+08:00"
categories="java"
+++

## Java 泛型经常使用的符号的含义

- T -- Type / java 类

- K -- Key / 键

- V -- Value / 值

- E -- Element / 集合中的元素

- ? -- 通配符

- S、U、V -- 2nd、3rd、4th types


## 参考连接

- [Java泛型中K T V E ？ object等的含义](www.hollischuang.com/archives/252)
