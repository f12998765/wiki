+++
title = "win10 系统重装手册"
date = "2017-01-18T12:00:00+08:00"
tags = ["win","手册"]
categories="system"
+++
## 删除 OneDriver 上的电脑
地址：[https://onedrive.live.com](https://onedrive.live.com)

## 清除同步隐私
地址：[https://account.microsoft.com/privacy#/](https://account.microsoft.com/privacy#/)

## 删除应用商店设备
地址：[https://account.microsoft.com/devices/store](https://account.microsoft.com/devices/store)

## 删除 Github 上的 SSH 密钥
地址：[https://github.com/settings/keys](https://github.com/settings/keys)

## 删除 Chrome 浏览器同步
地址：[https://www.google.com/settings/chrome/sync](https://www.google.com/settings/chrome/sync)