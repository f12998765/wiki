# 一个想法-favicon 

自己做了一个小东西，一个简单的 [网址索引](http://hao.xizero.com)。

因为要显示每个网站的favicon，google一下，找到了一些还能用公共的api。

- google：http://www.google.com/s2/favicons?domain=

- BYI_API：https://api.byi.pw/favicon/

其他的都不能用了，谷歌还要翻墙，最后就用了BYI_API。

一直都挺好的，被墙的网站也能返回，直到前几天（估计在11月12日左右），崩了（>\_<）。

面对满页的XX，我换了另一个。

- http://f.ydr.me/?url=

但是，满页的ie图标是要干啥（不支持的被墙的网站）

后来，看到了一个问答，大概是通过判断图片的MD5来判断是不是小地球（获取失败时返回），我灵感一动，两天的折磨……

前段框架用的是刚学的vue.js 2，用过滤器 filters 不就可以了吗？

```javascript

{{data_url  | filter}}
```

只要我把前面的链接获取到，然后判断那个图标是不是小地球，再来调用其他的api，不就可以了吗。

但是 vue 不支持在绑定属性中使用过滤器，（>\_<），好，再google，(⊙o⊙)哦，要用计算属性 computed 啊！？

但是计算属性不能传参，（>\_<），好，只能再找了，可以用 methods 。

之前学习了fetch，用fetch下图标，然后直接返回图片，这儿遇到点问题，主要是图片的处理和到最后也没有解决的跨域问题。

```javascript

fetch(img_url)
.then(function(res){
    return res.blob();
})
.then(function(imageBlob){
    img_src = window.URL.createObjectURL(imageBlob);
    //more
})
```
这是一个简单的fetch获取图片的例子，复刻官网上的，本地图片可以加载。

但是favicon api是不支持跨域请求，所以一直在做挣扎。

在这段时间之中，把这个方法放到了mounted，想让图片直接在加载时判断。

主要是因为好好的看了一下js的闭包，之前有过卡在这儿的经历，还好征服了。

```javascript

for(var i=0;i<json.length;i++){
    (function(i){
        for(var j=0;j<json[i].list.length;j++){
            (function(j){
                fetch(
                'https://s2.googleusercontent.com/s2/favicons?domain='
                +json[i].list[j].url,
                    {
                        mode:"cors",
                        headers:{
                        'Access-Control-Allow-Origin':'*'
                        }
                    }
                )
                .then(function(res){
                    return res.blob();
                })
                .then(function(imageBlob){
                    json[i].list[j].img
                    =window.URL.createObjectURL(imageBlob);
                })
            })(j);
        }
    })(i);
}

```

痛苦的是解决fetch 的跨域问题

fetch 的response 中有个mode的属性，可取值4个，包括 cors、no-cors等。

默认为cors，但在请求图片时，浏览器会提醒跨域问题。
当设置为 no-cors 时， 虽然不会报错，但是你并不能获取resquest 中的data，所以然并软。

还曾引入过fetch-jsonp.js，但是就像no-cors，获取不到内容。

设置请求头中的Access-Control-Allow-Origin，会提示服务器不支持。

就当我要放弃时，我又突发奇想，等网页加载完，判断下载本地的图片。

不能直接获取图片的MD5，找到了别人写的代码，先变成Base64.

```javascript

function getBase64Image(img) {
    var canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;

    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, img.width, img.height);

    var dataURL = canvas.toDataURL("image/png");
    return dataURL

    // return dataURL.replace("data:image/png;base64,", "");
}

```
接下来，用SparkMD5，讲Base64编码，再比较。

小心翼翼地试了下，好像可以。

但是，当我写好了代码，请求时，浏览器报错传到函数里面的不是一个HTMLElement。
我想是不是因为图片还没有加载完成，获取不到节点，那就判断一下。

```javascript

if (img.complete) {}
```

但是，**canvas** 不支持跨域 ！

所以，我放弃了。


我又重新看了一下开始的API，好像能用了，那就切换回来好了。

看到他的代码开源，想要自己整一个,以防万一。

（>_<）为什么是 拍X片 PHP ？？？


结束

后记

当我兴致勃勃的去用java写一个api时，我卡在了线程同步……
