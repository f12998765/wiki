# java 断言

基本格式

```java
assert  boolean ;
assert  boolean : error info;
```

默认关闭，开启命令
```
java -ea 字节码
```
